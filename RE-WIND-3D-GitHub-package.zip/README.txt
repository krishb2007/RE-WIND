RE-WIND · PHOTOREALISTIC HTML MOCKUP
=================================

Open index.html to see the three photorealistic mockup screens. The assets folder must stay next to index.html.

For GitHub Pages:
1. Upload index.html and the assets folder to your GitHub repository.
2. Make sure the images remain under assets/ exactly as referenced in index.html.
3. Open Settings > Pages and deploy from the main branch/root folder.

Alternatively, upload the standalone file RE-WIND-3D-standalone.html, renamed to index.html, into the repository root. The standalone version embeds all imagery and needs no assets folder.

Current functionality:
- Arrows and tabs switch between Settings, Player, and Library.
- Click album covers in Library to add discs to the queue.
- Hover album covers to lift them.
- The right-hand stack in Player visualizes queued albums.
- Clicking CDs in the queue removes them.
- The hardware playback buttons are clickable visual demos; there is no actual audio.

IMPORTANT: The realistic stereos/shelves/settings shown here are rendered IMAGE LAYERS, with real HTML hotspots. They are not individually editable 3D DOM objects or 3D models. The best hackathon progression is to connect actual file playback and replace selected image regions with layered interactive controls later.
